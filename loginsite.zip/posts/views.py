from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect

from posts.forms import SignUpForm

def index(request):
	context = {
		"page_title": "Index",
		"current_message": "Welcome! ",
	}
	return render(request, "posts/index.html", context)
	
def about(request):
	context = {
		"page_title": "About",
		"current_message": "About This Project ",
	}
	return render(request, "posts/about.html", context)
	
	
@login_required
def home(request):
	context = {
		"page_title": "Home",	 
	}
	return render(request, 'posts/home.html', context)


def signup(request):
	
	form = SignUpForm(request.POST or None)
	if form.is_valid():
		user = form.save(commit=False)
		username = form.cleaned_data['username']
		password = form.cleaned_data['password1']
		user.set_password(password)
		user.save()
		user = authenticate(username=username, password=password)
		if user is not None:
			if user.is_active:
				login(request, user)               
				return render(request, 'posts/home.html',)
	context = {
		"form": form,
		"page_title": "Sign Up",
	}
	return render(request, 'posts/signup.html', context)

	
def user_login(request):
	context = {
		"page_title": "Log In",	 
	}
	
	if request.method == "POST":
		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(username=username, password=password)
		if user is not None:
			if user.is_active:
				login(request,user)
				#posts = Post.objects.filter(user=request.user)
				context = {
					"login_message": "Login Success!",
					"page_title" : "Login",
					#"posts" : posts,
					}
				return HttpResponseRedirect('/posts/home/')
			else:
				return render(request,'posts/login.html',{'current_message' : 'Your Account has been disabled' })
		else:
			return render(request,'posts/login.html',{'current_message' : 'Invalid Login' })
	return render(request, "posts/login.html", context)

	
def user_logout(request):
	logout(request)
	#return HttpResponseRedirect('/posts/logout')
	return render(request, 'posts/logout.html',)
	
	

def projects(request):
	context = {
		"page_title": "Projects",	 
	}
	return render(request, 'posts/projects.html', context)
